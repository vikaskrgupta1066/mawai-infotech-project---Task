import serviceImage from '../assets/business-people-using-internet.jpg';

const BookingCard = () => {
  return (
    <div className="max-w-sm w-full bg-white shadow-md hover:shadow-xl rounded-2xl overflow-hidden transition-shadow duration-300">
      <img
        src={serviceImage}
        alt="Service"
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h2 className="text-xl font-semibold text-gray-800">Security Services</h2>
        <p className="text-gray-600 text-sm mt-1">Provider: Cyber Security Services</p>
        <p className="text-green-600 font-bold text-lg mt-2">₹1499</p>
        <button className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors">
          Book Now
        </button>
      </div>
    </div>
  );
};

export default BookingCard;
