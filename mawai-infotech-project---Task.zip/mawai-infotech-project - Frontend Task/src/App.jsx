import BookingCard from './components/BookingCard';

const App = () => {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <BookingCard />
    </div>
  );
};

export default App;
