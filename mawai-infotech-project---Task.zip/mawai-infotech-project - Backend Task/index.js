const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json()); 


// =======================================

// run command - npm run dev

// GET http://localhost:3000/services — get sample list
// POST http://localhost:3000/services — send JSON like:

// {
//   "name": "Facial Clean-up",
//   "provider": "Glow Beauty",
//   "price": 999
// }

// =======================================

// Sample service data
let services = [
  {
    id: 1,
    name: 'Spa Therapy',
    provider: 'RelaxHub',
    price: 1499
  },
  {
    id: 2,
    name: 'Haircut & Styling',
    provider: 'Style Studio',
    price: 799
  },
  {
    id: 3,
    name: 'Full Body Massage',
    provider: 'TherapyPoint',
    price: 1999
  }
];

// GET /services — return sample list
app.get('/services', (req, res) => {
  res.json(services);
});

// POST /services — add new service
app.post('/services', (req, res) => {
  const newService = req.body;

  if (!newService.name || !newService.provider || !newService.price) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  newService.id = services.length + 1;
  services.push(newService);

  res.status(201).json({ message: 'Service added', service: newService });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
